#include "ContClassTest.h"



ContClassTest::ContClassTest()
{
}


ContClassTest::~ContClassTest()
{
}
