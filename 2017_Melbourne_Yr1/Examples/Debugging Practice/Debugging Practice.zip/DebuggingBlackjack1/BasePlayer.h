#pragma once

#include "Constants.h"

class Card;
class Deck;

class BasePlayer
{
public:
	BasePlayer();
	
	void AddCardToHand(Card* pCard);
	virtual void DisplayCards() = 0;

	int GetScore();

protected:
	virtual ~BasePlayer();

	void CalculateScore();
	void FormatText(char* in, char* out, int outLength);

	Card* m_apHand[MAX_DECK_SIZE];
	int m_nCardsInHand;
	int m_nTotalCardScore;
};

