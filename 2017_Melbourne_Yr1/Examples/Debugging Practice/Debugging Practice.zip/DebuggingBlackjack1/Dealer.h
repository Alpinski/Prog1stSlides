#pragma once

#include "Constants.h"
#include "BasePlayer.h"

class Card;
class Deck;

class Dealer : public BasePlayer
{
public:
	Dealer();
	~Dealer();

	void DealersTurn(Deck* pDeck, BasePlayer* pPlayer);
	void DisplayCards();

};

