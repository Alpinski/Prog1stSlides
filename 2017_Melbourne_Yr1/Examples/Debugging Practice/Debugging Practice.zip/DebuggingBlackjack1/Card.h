#pragma once

#include "Constants.h"

class Card
{
public:
	Card(int nValue, ESUIT eSuit);
	~Card();

	int GetValue();
	ESUIT GetSuit();
	char* GetName();

private:
	int m_nValue;
	ESUIT m_eSuit;
	char* m_szName;
};

