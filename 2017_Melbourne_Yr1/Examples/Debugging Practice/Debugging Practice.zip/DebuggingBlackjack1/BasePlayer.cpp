#include "BasePlayer.h"

#include <iostream>
#include "Card.h"
#include "Deck.h"

using namespace std;

BasePlayer::BasePlayer()
{
	m_nCardsInHand = 0;
	m_nTotalCardScore = 0;
}

BasePlayer::~BasePlayer()
{
}

void BasePlayer::AddCardToHand(Card* pCard)
{
	m_apHand[m_nCardsInHand] = pCard;
	++m_nCardsInHand;

	CalculateScore();
}

void BasePlayer::CalculateScore()
{
	int nAceCount = 0;
	m_nTotalCardScore = 0;

	for (int i = 0; i <= m_nCardsInHand; ++i)
	{
		int nCardValue = m_apHand[i]->GetValue();

		if (nCardValue == 1)
		{
			++nAceCount;
			m_nTotalCardScore += 11;
			continue;
		}

		if (nCardValue > 10)
			nCardValue = 10;

		m_nTotalCardScore += nCardValue;
	}

	for (int i = 0; i < nAceCount; ++i)
	{
		if (m_nTotalCardScore > 21)
			m_nTotalCardScore -= 10;
	}
}

int BasePlayer::GetScore()
{
	return m_nTotalCardScore;
}

void BasePlayer::FormatText(char* in, char* out, int outLength)
{
	if(outLength < 24)
	{
		cout << "Error, string not long enough";
		return;
	}

	int inLength = strlen(in);
	strcpy_s(out, outLength, in);
	for(int i = inLength; i < 22; ++i)
	{
		out[i] = ' ';
	}
	out[22] = '\0';
}