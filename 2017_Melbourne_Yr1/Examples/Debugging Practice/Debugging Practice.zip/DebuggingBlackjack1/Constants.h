#pragma once

#define MAX_NAME_SIZE 64
#define SUIT_SIZE 13

enum ESUIT
{
	ESUIT_SPADES = 0,
	ESUIT_CLUBS,
	ESUIT_HEARTS,
	ESUIT_DIAMONDS,

	ESUIT_COUNT
};

#define MAX_DECK_SIZE (SUIT_SIZE * ESUIT_COUNT)

#define BUST 21