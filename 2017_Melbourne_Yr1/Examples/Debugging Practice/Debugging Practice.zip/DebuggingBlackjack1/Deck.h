#pragma once

#include "Constants.h"

class Card;

class Deck
{
public:
	Deck();
	~Deck();

	Card* DrawCard();

private:
	Card* m_apDeck[MAX_DECK_SIZE];
	bool m_abCardDrawn[MAX_DECK_SIZE];
};

