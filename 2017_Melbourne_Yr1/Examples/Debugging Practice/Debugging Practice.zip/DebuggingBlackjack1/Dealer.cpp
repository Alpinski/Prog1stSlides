#include "Dealer.h"

#include <iostream>
#include "Card.h"
#include "Deck.h"

using namespace std;

Dealer::Dealer()
{
}

Dealer::~Dealer()
{
}

void Dealer::DealersTurn(Deck* pDeck, BasePlayer* pPlayer)
{
	bool bDealersTurn = true;
	bool bFirst = true;
		
	AddCardToHand(pDeck->DrawCard());
	AddCardToHand(pDeck->DrawCard());

	while(bDealersTurn = true)
	{
		system("cls");
		pPlayer->DisplayCards();

		if(bFirst)
		{
			cout << endl << "   The dealer has: " << endl;
			bFirst = false;
		}
		else
		{
			Card* pNewCard = pDeck->DrawCard();
			cout << endl;
			cout << "   Dealer draws a " << pNewCard->GetName() << endl << endl;
			AddCardToHand(pNewCard);
		}
		DisplayCards();

		int score = GetScore();
		int playersScore = pPlayer->GetScore();
		if(score > BUST)
		{
			//Bust
			cout << endl;
			cout << "   Dealer busts!" << endl;
			cout << "   You win!" << endl << endl;
			bDealersTurn = false;
		}
		else if(score > playersScore)
		{
			//Win
			cout << endl;
			cout << "   Dealer wins!" << endl << endl;
			bDealersTurn = false;
		}
		else
		{
			cout << endl;
			cout << "   ";
			system("pause");
		}
	}
}

void Dealer::DisplayCards()
{
	char buffer[32];

	cout << endl;
	cout << "   ------------------------" << endl;
	cout << "  |                        |" << endl;
	cout << "  | The dealer has:        |" << endl;
	cout << "  |                        |" << endl;

	for (int i = 0; i < m_nCardsInHand; ++i)
	{
		FormatText(m_apHand[i]->GetName(), buffer, 32);
		
		cout << "  |  " << buffer;
		cout << "|" << endl;
	}

	cout << "  |                        |" << endl;
	sprintf_s(buffer, 32, "Total: %d", m_nTotalCardScore);
	FormatText(buffer, buffer, 32);
	cout << "  | " << buffer << " |" << endl;
	cout << "  |                        |" << endl;
	cout << "   ------------------------" << endl;
}
