#pragma once

#include "Constants.h"
#include "BasePlayer.h"

class Card;
class Deck;

class Player : public BasePlayer
{
public:
	Player();
	~Player();

	bool PlayersTurn(Deck* pDeck);
	void DisplayCards();

};

