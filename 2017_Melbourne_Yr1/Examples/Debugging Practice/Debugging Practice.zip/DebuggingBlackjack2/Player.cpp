#include "Player.h"

#include <iostream>
#include "Card.h"
#include "Deck.h"

using namespace std;

Player::Player()
{
}

Player::~Player()
{
}

bool Player::PlayersTurn(Deck* pDeck)
{
	bool bPlayersTurn = true;
	while (bPlayersTurn)
	{
		char buffer;
		cout << endl;
		cout << "   What whould you like to do?" << endl;
		cout << "   (H)it or (S)tand?" << endl << endl;
		cout << "   >";
		cin >> buffer;
		cin.clear();
		cin.ignore(10000, '\n');

		switch (buffer)
		{
		case 'h':
		case 'H':
		{
			system("cls");
			Card* pNewCard = pDeck->DrawCard();
			cout << endl << "   You are dealt the " << pNewCard->GetName() << endl;
			AddCardToHand(pNewCard);
		}
		break;

		case 's':
		case 'S':
			return true;
			break;
		}

		DisplayCards();

		if (GetScore() > BUST)
		{
			cout << endl << "   Bust!" << endl << "   You lose!" << endl << endl;
			return false;
		}
	}
	return true;
}

void Player::DisplayCards()
{
	cout << endl;
	cout << "   ------------------------" << endl;
	cout << "  |                        |" << endl;
	cout << "  | Your cards are:        |" << endl;
	cout << "  |                        |" << endl;

	for (int i = 0; i < m_nCardsInHand; ++i)
	{
		FormatText(m_apHand[i]->GetName(), buffer, 32);
		
		cout << "  |  " << buffer;
		cout << "|" << endl;
	}

	cout << "  |                        |" << endl;
	sprintf_s(buffer, 32, "Total: %d", m_nTotalCardScore);
	FormatText(buffer, buffer, 32);
	cout << "  | " << buffer << " |" << endl;
	cout << "  |                        |" << endl;
	cout << "   ------------------------" << endl;

}
