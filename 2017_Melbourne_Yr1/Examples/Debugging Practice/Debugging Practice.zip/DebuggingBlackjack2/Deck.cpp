#include "Deck.h"

#include <iostream>
#include "Card.h"

Deck::Deck()
{
	for (int suit = 0; suit < ESUIT_COUNT; suit++)
	{
		for (int value = 0; value < SUIT_SIZE; value++)
		{
			int index = (suit * SUIT_SIZE) + value;

			m_apDeck[index] = new Card(value + 1, (ESUIT)suit);
		}
	}

	for (int i = 0; i < MAX_DECK_SIZE; i++)
	{
		m_abCardDrawn[i] = false;
	}
}

Deck::~Deck()
{
	for (int i = 0; i < MAX_DECK_SIZE; i++)
	{
		delete m_apDeck[i];
		m_apDeck[i] = nullptr;
	}
}

Card* Deck::DrawCard()
{
	double r = rand() % MAX_DECK_SIZE;

	while (m_abCardDrawn[r])
	{
		r = rand() % MAX_DECK_SIZE;
	}

	m_abCardDrawn[r] = true;

	return m_apDeck[r];
}