#include <iostream>
#include <time.h>

#include "Deck.h"
#include "BasePlayer.h"
#include "Player.h"
#include "Dealer.h"
#include "Card.h"

using namespace std;

void PrintIntro()
{
	cout << endl;
	cout << "   /====================================\\  " << endl;
	cout << "  |======================================| " << endl;
	cout << "  |                                      | " << endl;
	cout << "  |         WELCOME TO BLACKJACK         | " << endl;
	cout << "  |                                      | " << endl;
	cout << "  |======================================| " << endl;
	cout << "   \\====================================/  " << endl << endl;
}

int main()
{
	srand((unsigned int)time(0));

	bool bPlaying = true;

	while(bPlaying)
	{
		Deck* pDeck = new Deck();
		Player* pPlayer = new Player;
		Dealer* pDealer = new Dealer;

		PrintIntro;
		cout << "       ";
		system("pause");
		system("cls");

		//Deal
		pPlayer->AddCardToHand(pDeck.DrawCard());
		pPlayer->AddCardToHand(pDeck.DrawCard());
		cout << endl << "   Your cards are dealt:" << endl;
		pPlayer->DisplayCards();

		bool bStand = pPlayer->PlayersTurn(pDeck);
		if(bStand)
		{
			pDealer->DealersTurn(pDeck, pPlayer);
		}

		cout << "   ";
		system("pause");

		system("cls");
		char buffer;
		cout << endl;
		cout << "   Play again?" << endl;
		cout << "   (Y)es or (N)o" << endl << endl;
		cout << "   >";
		cin >> buffer;
		cin.clear();
		cin.ignore(10000, '\n');
		bPlaying = (buffer == 'y' || buffer == 'Y');
		system("cls");

		delete pDealer;
		delete pPlayer;
		delete pDeck;
	}
}