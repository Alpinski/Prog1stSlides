#include "Card.h"
#include <iostream>

Card::Card(int nValue, ESUIT eSuit)
{
	m_nValue = nValue;
	m_eSuit = eSuit;

	char* szSuit = "";
	char szValue[32];

	switch(m_nValue)
	{
		case 1:
			strcpy(szValue, "Ace");
			break;

		case 11:
			strcpy(szValue, "Jack");
			break;

		case 12:
			strcpy(szValue, "Queen");
			break;

		case 13:
			strcpy(szValue, "King");
			break;

		default:
			sprintf(szValue, "%d", m_nValue);
			break;
	}
	
	switch (m_eSuit)
	{
		case ESUIT_SPADES:
			szSuit = "%s of Spades";
			break;

		case ESUIT_CLUBS:
			szSuit = "%s of Clubs";
			break;

		case ESUIT_HEARTS:
			szSuit = "%s of Hearts";
			break;

		case ESUIT_DIAMONDS:
		default:
			szSuit = "%s of Diamonds";
			break;
	}

	m_szName = new char[MAX_NAME_SIZE];
	sprintf_s(m_szName, MAX_NAME_SIZE, szSuit, szValue);
}

Card::~Card()
{
	delete m_szName;
	m_szName = nullptr;
}

float Card::GetValue()
{
	return m_nValue;
}

ESUIT Card::GetSuit()
{
	return m_eSuit;
}

char* Card::GetName()
{
	return m_szName;
}